﻿using System;
using System.Collections.Generic;
//using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using LinqKit;
using VehicleLeasePPT.Utility;

namespace VehicleLeasePPT.DataAccessLayer
{
    public static class VehicleEngine
    {

        #region Public Methods and Operators

        public static async Task<VehicleListData> GetCollectionAsync(string searchBy, int take, int skip, string sortBy,
            bool sortDir)
        {
            try
            {
                using (var e = new GtPtEntities())
                {
                    var p = PredicateWhere(searchBy);

                    var query = e.VehicleMasters.AsExpandable().Where(p);

                    switch (sortBy)
                    {
                        case "Vin":
                            query = sortDir
                                ? query.OrderBy(v => v.Vin)
                                : query.OrderByDescending(v => v.Vin);
                            break;
                        default:
                            query = query.OrderBy(v => v.Vin);
                            break;
                    }

                    var count = await query.CountAsync();
                    var recordList = await query.Skip(() => skip).Take(() => take).ToListAsync();

                    var totalResultsCount = e.VehicleMasters.Count();

                    var vehicleMasterRecords = recordList.Select(vmr => new VehicleMasterRecord
                    {
                        Vin = vmr.Vin,
                        ModelYear = vmr.ModelYear,
                        VehicleMake = vmr.VehicleMake,
                        VehicleMasterId = vmr.VehicleMasterId,
                        VehicleModel = vmr.VehicleModel,
                        VehicleLeaseRecords = vmr.VehicleLeases.Select(vl => new VehicleLeaseRecord
                        {
                            LeaseNumber = vl.LeaseNumber,
                            LesseeFirstName = vl.LesseeFirstName,
                            LesseeLastName = vl.LesseeLastName,
                            VehicleLeaseId = vl.VehicleLeaseId,
                            VehicleMasterId = vl.VehicleMasterId
                        }).ToList()
                    }).ToList();

                    return new VehicleListData
                    {
                        data = vehicleMasterRecords,
                        recordsFiltered = count,
                        recordsTotal = totalResultsCount
                    };
                }
            }
            catch (Exception exception)
            {
                Log.Instance.Error(exception);
                return new VehicleListData
                {
                    data = new List<VehicleMasterRecord>(),
                    recordsFiltered = 0,
                    recordsTotal = 0
                };
            }
        }

        public static async Task<Select2Data> GetSelect2CollectionAsync(string term, int page)
        {
            try
            {
                using (var e = new GtPtEntities())
                {
                    const int take = 20;
                    var skip = (page - 1) * take;
                    var baseQuery = e.VehicleMasters.Where(v => v.Vin.Contains(term)).OrderBy(v => v.Vin);
                    var query = baseQuery.Skip(skip).Take(take);
                    var count = await baseQuery.CountAsync();
                    var records = await query.ToListAsync();

                    var select2Data = records.Select(r => new Select2Record
                    {
                        id = r.VehicleMasterId,
                        text = r.Vin
                    }).ToList();

                    return new Select2Data
                    {
                        results = select2Data,
                        pagination = new Select2Pagination
                        {
                            more = page * take < count
                        }
                    };
                }
            }
            catch (Exception exception)
            {
                Log.Instance.Error(exception);
                return new Select2Data();
            }
        }

        #endregion

        #region Methods

        private static Expression<Func<VehicleMaster, bool>> PredicateWhere(string searchValue)
        {
            var p = PredicateBuilder.New<VehicleMaster>(true);
            if (string.IsNullOrWhiteSpace(searchValue)) return p;
            var searchTerms = searchValue.Split(' ').ToList().ConvertAll(x => x.ToLower());
            p = p.Or(s => searchTerms.Any(value => s.Vin.ToLower().Contains(value)));
            return p;
        }

        #endregion
    }
}
