﻿namespace VehicleLeasePPT.DataAccessLayer
{
    public class RedeemedToken
    {

        #region Public Properties

        public bool BypassTwoFactor { get; set; }
        public int PersonId { get; set; }

        #endregion
    }
}
