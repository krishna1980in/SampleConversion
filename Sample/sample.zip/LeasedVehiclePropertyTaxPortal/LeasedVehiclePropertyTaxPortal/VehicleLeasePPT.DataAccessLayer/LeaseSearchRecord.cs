﻿namespace VehicleLeasePPT.DataAccessLayer
{
    public class LeaseSearchRecord
    {

        #region Public Properties

        public string LeaseNumber { get; set; }
        public string LesseeFirstName { get; set; }
        public string LesseeFullName => $"{LesseeLastName}, {LesseeFirstName}";
        public string LesseeLastName { get; set; }
        public string ModelYear { get; set; }
        public int VehicleLeaseId { get; set; }
        public string VehicleMake { get; set; }
        public int VehicleMasterId { get; set; }
        public string VehicleModel { get; set; }

        // ReSharper disable once InconsistentNaming
        public string VIN { get; set; }

        #endregion
    }
}
