﻿using System.Collections.Generic;

namespace VehicleLeasePPT.DataAccessLayer
{
    public class VehicleMasterRecord
    {

        #region Public Properties

        public string ModelYear { get; set; }
        public IEnumerable<VehicleLeaseRecord> VehicleLeaseRecords { get; set; }
        public string VehicleMake { get; set; }
        public int VehicleMasterId { get; set; }
        public string VehicleModel { get; set; }
        public string Vin { get; set; }

        #endregion
    }
}
