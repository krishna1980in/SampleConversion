﻿namespace VehicleLeasePPT.DataAccessLayer
{
    public class FileRecord
    {

        #region Public Properties

        public byte[] Bytes { get; set; }
        public string FileName { get; set; }

        #endregion
    }
}
