﻿window.utc_aft = "";
$(document).ready(function () {
    window.utc_aft = $("#aft").data("token");
    $("#vehicle_table").DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "/api/VehicleData",
            "type": "POST",
            headers: {
                'RequestVerificationToken': window.utc_aft
            }
        },
        "order": [[0, "asc"]],
        "columns": [
            {
                "className": "td-nowrap",
                "data": "Vin"
            },
            {
                "className": "td-nowrap",
                "data": "VehicleMake",
                "orderable": false
            },
            {
                "className": "td-nowrap",
                "data": "VehicleModel",
                "orderable": false
            },
            {
                "className": "td-nowrap",
                "data": "ModelYear",
                "orderable": false
            },
            {
                "className": "td-nowrap action",
                "data": "VehicleMasterId",
                "orderable": false,
                "render":
                    function (data, type, row, meta) {
                        return '<a class="btn btn-secondary btn-sm" href="/Vehicle/Detail/' +
                            data +
                            '">View</a> <a class="btn btn-secondary btn-sm" href="/Vehicle/Edit/' +
                            data +
                            '">Edit</a>';
                    }
            }
        ]
    });
});