﻿using System;

namespace VehicleLeasePPT.Models
{
    public class BlockedPersonViewModel
    {

        #region Public Properties

        public DateTime ExpirationDateTime { get; set; }
        public string TimeZone { get; set; }

        #endregion
    }
}
