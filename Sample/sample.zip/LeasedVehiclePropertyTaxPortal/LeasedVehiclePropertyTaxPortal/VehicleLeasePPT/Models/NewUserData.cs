﻿namespace VehicleLeasePPT.Models
{
    public class NewUserData
    {

        #region Public Properties

        public string EmailAddress { get; set; }
        public string FullName { get; set; }
        public string PreferredName { get; set; }

        #endregion
    }
}
