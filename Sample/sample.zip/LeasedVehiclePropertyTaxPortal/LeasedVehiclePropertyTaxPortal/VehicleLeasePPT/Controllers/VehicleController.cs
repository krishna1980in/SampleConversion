﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using VehicleLeasePPT.Filters;

namespace VehicleLeasePPT.Controllers
{
    [Authorize]
    
[Route("vehicle")]
    public class VehicleController : BaseController
    {

        #region Public Methods and Operators

        // GET: Vehicle
        public ActionResult Index()
        {
            return View();
        }

        #endregion
    }
}
