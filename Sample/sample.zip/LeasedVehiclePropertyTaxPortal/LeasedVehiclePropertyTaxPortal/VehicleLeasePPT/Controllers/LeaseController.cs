﻿using System.Net.Mime;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using VehicleLeasePPT.DataAccessLayer;
using VehicleLeasePPT.Filters;
using VehicleLeasePPT.Models;
using VehicleLeasePPT.Utility;

namespace VehicleLeasePPT.Controllers
{
    [Authorize]
    
[Route("lease")]
    public class LeaseController : BaseController
    {

        #region Public Methods and Operators

        public async Task<ActionResult> Detail(int id = -1)
        {
            if (id.Equals(-1)) return RedirectToAction("Index");
            var p = await LeaseEngine.GetVehicleLeaseAsync(id);
            if (p == null) return RedirectToAction("Index");
            var model = new LeaseDetailViewModel
            {
                ActualTerminationDate = p.ActualTerminationDate,
                AssetNumber = p.AssetNumber,
                AssetStatusName = p.AssetStatusName,
                BranchCode = p.BranchCode,
                CommencementDate = p.CommencementDate,
                CompanyCode = p.CompanyCode,
                CompanyName = p.CompanyName,
                ExemptionCode = p.ExemptionCode,
                LeaseNumber = p.LeaseNumber,
                LeaseStatusName = p.LeaseStatusName,
                LesseeFirstName = p.LesseeFirstName,
                LesseeLastName = p.LesseeLastName,
                ModelYear = p.ModelYear,
                OriginalCost = p.OriginalCost,
                PayoffSource = p.PayoffSource,
                PlateNumber = p.PlateNumber,
                ProductUseCode = p.ProductUseCode,
                RegistrationState = p.RegistrationState,
                SaleDate = p.SaleDate,
                SalesPrice = p.SalesPrice,
                ScheduledTerminationDate = p.ScheduledTerminationDate,
                TaxRecoveryCode = p.TaxRecoveryCode,
                TerminationCode = p.TerminationCode,
                VehicleLeaseId = p.VehicleLeaseId,
                VehicleMake = p.VehicleMake,
                VehicleMasterId = p.VehicleMasterId,
                VehicleModel = p.VehicleModel,
                Vin = p.Vin,
                TaxBillVehicleLeaseRecords = p.TaxBillVehicleLeaseRecords,
                PhysicalAddressRecords = p.PhysicalAddressRecords,
                CustomerAddressRecords = p.CustomerAddressRecords,
                LeaseAttachmentRecords = p.LeaseAttachmentRecords
            };
            return View(model);
        }

        // GET: Lease
        public ActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> ViewAttachment(int id = -1)
        {
            if (id.Equals(-1)) return null;
            var fr = await LeaseEngine.GetAttachmentAsync(id);
            if (fr == null) return null;

            var contentDispostion = new ContentDisposition
            {
                FileName = $"{fr.FileName}",
                Inline = false
            };
            Response.AddHeader("content-disposition", contentDispostion.ToString());
            Response.AddHeader("content-length", fr.Bytes.Length.ToString());
            return File(fr.Bytes, MimeType.Pdf);
        }

        #endregion
    }
}