﻿using System;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using VehicleLeasePPT.Helpers;
using VehicleLeasePPT.Utility;

namespace VehicleLeasePPT.Controllers
{
[Route("accessdenied")]
    public class AccessDeniedController : Controller
    {

        #region Public Methods and Operators

        public ActionResult AuthenticationError()
        {
            return View();
        }

        // GET: AccessDenied
        public ActionResult Index()
        {
            return RedirectToAction("Login", "Account");
        }

        public ActionResult RestrictedUser()
        {
            try
            {
                var bannedIpData = AuthenticationHelper.GetBlockCookie(Microsoft.AspNetCore.HttpContext.Current);
                var bannedIpData = AuthenticationHelper.GetBlockCookie(Microsoft.AspNetCore.MvcContext.Current);

                if (bannedIpData != null) return View(bannedIpData);
            }
            catch (Exception exception)
            {
                Log.Instance.Error(exception);
            }

            return RedirectToAction("Login", "Account");
        }

        #endregion
    }
}
