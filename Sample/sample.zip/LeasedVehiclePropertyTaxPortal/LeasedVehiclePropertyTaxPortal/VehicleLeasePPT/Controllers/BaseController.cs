﻿using System.Web;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
//using Microsoft.Owin.Security;
using VehicleLeasePPT.Filters;
using VehicleLeasePPT.Utility;

namespace VehicleLeasePPT.Controllers
{
    [RequireHttps]
    [LogAction]
[Route("base")]
    public class BaseController : Controller
    {

        #region Properties

        protected IAuthenticationManager AuthenticationManager => HttpContext.GetOwinContext().Authentication;

        #endregion

        #region Methods

        protected override void HandleUnknownAction(string actionName)
        {
            // When an Unknown action is called, redirect to Home/Index
            RedirectToAction("Index", "Home").ExecuteResult(ControllerContext);
        }

        protected override void OnException(ExceptionContext exceptionContext)
        {
            if (exceptionContext.ExceptionHandled) return;
            exceptionContext.ExceptionHandled = true;
            Log.Instance.Error(exceptionContext.Exception);
            RedirectToAction("FiveHundred", "Error").ExecuteResult(ControllerContext);
        }

        #endregion
    }
}
