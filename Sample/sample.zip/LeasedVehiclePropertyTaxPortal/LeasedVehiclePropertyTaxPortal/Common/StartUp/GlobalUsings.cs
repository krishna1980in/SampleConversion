﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Common
{
    class GlobalUsings
    {
    }
}
//for .net 6
//global using System.Threading.Tasks;
//global using System;