﻿using System;

namespace VehicleLeasePPT.Spreadsheet
{
    public class EpPlusIgnore : Attribute
    {

    }
}
